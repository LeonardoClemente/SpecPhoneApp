% %This file makes a back up list
% 
% k=uigetdir();
% temp_struct=dir(k);
% cell_list=extractfield(temp_struct,'name');
% list_table=cell2table(cell_list');
% dt=char(date);
% file_name=strcat(k,'_backuplist_',dt,'.csv');
% writetable(list_table,file_name);
% 

kk=uigetdir();
sites=findsites(kk);
sequences=cell(1,1);
m=size(sites,2)


for i=1:m
    wd=strcat(kk,'/',sites{i})
    sequences{i,1}=findSequences(wd)
end
    
        
   