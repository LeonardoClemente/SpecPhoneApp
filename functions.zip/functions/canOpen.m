function x = canOpen(wd)


try
    main=xmlread(wd);
    x=1;
catch error
    disp('Not able to read XML file. Please check for correct format');
    x=0;
end

end
