function newcell = cont2cell(cont)
k=keys(cont);
n=length(k);
newcell=cell(n,2);

for i=1:n
    newcell{i,1}=k{i};
    newcell{i,2}=cont(k{i});
end
end