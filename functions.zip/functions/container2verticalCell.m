function verticalCell= container2verticalCell(C);
k=keys(C);;
L=length(k);
vect=zeros(1,L);
for i=1:L

    len=length(C(k{i}));
    vect(i)=len;

end
verticalCell=cell(max(vect),L+1);

for i=2:L+1
    
    data=C(k{i-1});
    data=[k{i-1}
        data];
    for j=1:length(data)
        verticalCell{j,i}=data{j};
    end
end