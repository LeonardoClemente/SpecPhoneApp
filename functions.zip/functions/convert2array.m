function [dataArray,strCheck] = convert2array(parameterName,dataCell)

%Finding parameter on spreadsheet
names=dataCell(1,:);
[tf,index]=ismember(parameterName,names);
strCheck=0;

if tf == 1

         
%          
% 
%          [C,uniqueIndices,rebuildVector] = unique(dataColumn);
%          
%          [tf , index] = ismember('noData',C);
%          
%          if tf == 1
%          offIndices=find(rebuildVector==index);
%          dataColumn(offIndices(:))={'  -1'};
%          end
%          
%          [tf, index] = ismember('OFF                 ',C);
%          
%          if tf == 1
%          offIndices=find(rebuildVector==index);
%          dataColumn(offIndices(:))={'  -2'};
%          end
%          
%          [tf, index] = ismember('error',C);
% 
%          if tf == 1
%          offIndices=find(rebuildVector==index);
%          dataColumn(offIndices(:))={'  -3'};
%          end
    
         dataColumn=dataCell(2:end,index);        ;
         
         switch parameterName
             
             case {'latitude','longitude'}
             case{'altitude'}
                dataColumn=strrep(dataColumn,'M','');
             case{'time'}
                 dataColumn=strrep(dataColumn,':','');
                 dataColumn=strrep(dataColumn,'-','');
                 dataColumn=strrep(dataColumn,' ','');
             case{'temperature','bptemperature','temperatureStart','bptemperatureStart','temperatureEnd','bptemperatureEnd'}
                 dataColumn=strrep(dataColumn,'F','');
             case {'pressure'}
                 dataColumn=strrep(dataColumn,'mbar','');
                 dataColumn=strrep(dataColumn,'in Hg','');
             case {'humidity','humidityStart','humidityEnd'}
                 dataColumn=strrep(dataColumn,'%','');
             case {'UnitID'}
                 dataColumn=strrep(dataColumn,'Unit','');
             case {'antennaPower','swversion','waypoint','cable0SerialNum', 'cable1SerialNum', 'cable2SerialNum','cable3SerialNum'...
                    'sensor0SerialNum','sensor1SerialNum','sensor2SerialNum','sensor3SerialNum','completionCode','DataSetName'}
                 dataColumn(:)={'1'};
                 strCheck=1;
         end
                
         dataColumn=strrep(dataColumn,'noData','-1');
         dataColumn=strrep(dataColumn,'OFF','-2');
         dataColumn=strrep(dataColumn,'error','-3');
         dataArray=loopthrough(dataColumn,strCheck);
         
         
    
    
end

end

function dataArray = loopthrough(dataColumn,strCheck)
dataArray=zeros(size(dataColumn,1),1);
if strCheck == 0
                 for i=1:size(dataColumn,1)
                     dataArray(i)=str2num(dataColumn{i});
                 end
else
     for i=1:size(dataColumn,1)
     dataColumn(i,1)=dataColumn{i};
     end
end
    
end
