function [n_restarts,k] = countRestarts(wd)

n_restarts=0;
k=0;
try 
    
main=xmlread(wd);
restarts=main.getElementsByTagName('restart');

for i=0:restarts.getLength-1
    dato=restarts.item(i).getFirstChild.getData;
    if str2num(dato)  ~= 0
        n_restarts=n_restarts+1;
    end
end

catch error

    k=1;
end


end