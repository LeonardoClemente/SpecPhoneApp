function truefalse = datacheck(wd)

%CHECKS IF DATA HAS AT LEAST 1 LONG, if it does, it extracts the
%datasetinfo from it *supposing dataset info structure remains the same if
%there's more than 1 long*

%wd='/Volumes/thomas/testingbatch/BS001/D15-03-08T14-19-10SZUZ-WQQ'; %TEST

%wd='/Volumes/thomas/testingbatch/BS001';
tempstruct=dir(wd);
data=extractfield(tempstruct,'name'); %directory list

[t1, index] = ismember('short.bin', data);

[t2, index] = ismember('DatasetInfo.xml', data);

truefalse=t1*t2;

end