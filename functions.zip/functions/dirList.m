function x = dirList(ABSPATH)

    temp=dir(ABSPATH);
    k=extractfield(temp,'name');
    c=1;
    x={};
    
        for i=1:length(k)

            if strcmp(k{i},'.') == 0 && strcmp(k{i},'..') == 0 && strcmp(k{i},'.DS_Store') == 0
                x{c}=k{i};
                c=c+1;
            end
        end
        
end
