function newCell = evalBoolean(myFunction,parameterNames,dataCell)
dataHolder=containers.Map;
N=size(parameterNames,2);
n=size(dataCell,1)-1;
names=dataCell(1,:);
indices=zeros(1,N);
filteredIndices=(0);
arrayCell=cell(n,0);

for i=1:N
    [tf,index]=ismember(parameterNames{i},names);
    indices(i)=index;
    dataArray=convertDataCell(parameterNames{i},dataCell);
    arrayCell=[arrayCell dataArray];
end

for i=1:n
     tf=myFunction(arrayCell(i,:));
     if tf == 1
         filteredIndices=[filteredIndices i];
     end 
end
filteredIndices=filteredIndices+1;
newCell=dataCell(filteredIndices(:),:);
