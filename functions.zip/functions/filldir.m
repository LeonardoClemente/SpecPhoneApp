function x = filldir(main_folder,seq,waypoint_folder,seq_name,waypoint_name)
seq=char(seq);
%Actualizar la lista de directorios
tempstruct=dir(main_folder);
syncell=extractfield(tempstruct,'name');

%Ver si el directorio existe
tf=ismember(waypoint_name,syncell);

if tf == 1
    movefile(seq,waypoint_folder)
    disp('Folder already exists')
else
    mkdir(waypoint_folder)
    movefile(seq,waypoint_folder)
end
end