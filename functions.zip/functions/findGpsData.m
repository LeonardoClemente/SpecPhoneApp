function [gpsData,c4] = findGpsData(wd)
lat=0;
long=0;
c4=1;
try 
    
main=xmlread(wd);
lat_node=main.getElementsByTagName('latitude');
long_node=main.getElementsByTagName('longitude');

lat=str2num(lat_node.item(0).getFirstChild.getData);
long=str2num(long_node.item(0).getFirstChild.getData);


gpsData{1,1}=lat;
gpsData{1,2}=long;


catch error

   %disp('Unable to retrieve GPS data. Please check XML file for errors.')
   gpsData{1,1}='error';
   gpsData{1,2}='error';
   c4=0;
end



end