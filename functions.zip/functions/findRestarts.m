function [n_restarts, c3] = findRestarts(wd)

n_restarts=0;
c3=1;
try 
    
main=xmlread(wd);
restarts=main.getElementsByTagName('restart');

for i=0:restarts.getLength-1
    dato=restarts.item(i).getFirstChild.getData;
    if str2num(dato)  ~= 0
        n_restarts=n_restarts+1;
    end
end

catch error
    %disp('Not able to retreive restart data. Please check XML file for errors.')
    n_restarts='error';
    c3=0;
end


end