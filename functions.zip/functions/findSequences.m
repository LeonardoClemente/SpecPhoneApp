function seq = findSequences(wd)

%Encuentra el numero de syncs. 
% Wd es el directorio del site

seq=cell(1,1);

%wd='/Volumes/thomas/testingbatch/BS001';
tempstruct=dir(wd);
nafpcell=extractfield(tempstruct,'name');

for i=1:length(nafpcell)
    if length(nafpcell{i})==26 || length(nafpcell{i})==30
        seq=[seq
nafpcell{i}];
    end
end

seq=seq(2:end)

end