function [unitName, c2] = findUnit(wd)

c2=0;
try  
main=xmlread(wd);
sub_node=main.getElementsByTagName('UnitID');
ID_node=char(sub_node.item(0).getFirstChild.getData);
unitName=ID_node(length(ID_node)-1:end); 
catch error
    %disp('Could not retrieve AFP number. Please check XML file for errors.');
    unitName='error';
    c2=0;
end


end