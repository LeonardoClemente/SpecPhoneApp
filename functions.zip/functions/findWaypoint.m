function [waypoint_name, c1] = findWaypoint(wd)

n_restarts=0;
c1=1;

try 
    
main=xmlread(wd);
waypoint_node=main.getElementsByTagName('waypoint');
waypoint_name=waypoint_node.item(0).getFirstChild.getData;
disp(waypoint_name);
waypoint_name=char(waypoint_name); %Nueva
catch error
    %disp('Could not retrieve waypoint data. Please check XML file for errors.')
    waypoint_name='error';
    c1=0;
end


end