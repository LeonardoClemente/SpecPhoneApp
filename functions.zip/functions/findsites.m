function [sites,r] = findsites(kd)

%Find sites.
c=1;
r=0;
sites={};

tempstruct=dir(kd);
syncell=extractfield(tempstruct,'name');

for i=1:length(syncell)
    
    p=syncell{i};
    pl=length(p);
    if pl==5
        sites{c}=p;
        c=c+1;
    end
    
    if pl==6 & (p(pl) =='r' || p(pl)=='R')
        sites{c}=p;
        c=c+1;
        r=r+1;
    end
    
end
        
end