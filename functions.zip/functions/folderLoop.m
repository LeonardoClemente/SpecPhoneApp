function xmlDirList = folderLoop(PATH,docName,excludeList)
c=1;
done=false;
dirs=cell(1,0);
dirs{1}=PATH;
dirs{2}='end';
MAINPATH='';
xmlcounter=0;
xmlDirList=cell(1,0);

%PROGRAM GOES THROUGH A DATABASE LOOKING FOR XML FILES
while done == false
    
    
    MAINPATH=dirs{c};
    
    if strcmp(MAINPATH,'end') ==0
        currentDirList=dirList(MAINPATH);
        
        %EXCLUDING FILES
        if c==1
           N=size(excludeList,2);
           for i=1:N
               [t, index] = ismember(excludeList{i}, currentDirList);
               
               if t == 1
                  if index == 1
                      currentDirList=currentDirList(2:end);
                  end
                  
                  if index == size(currentDirList,2);
                      currentDirList=currentDirList(1:index-1);
                  end
                  
                  if index ~= 1 && index~= size(currentDirList,2);
                      prev=currentDirList(1:index-1);
                      post=currentDirList(index+1:end);
                      currentDirList=[prev post];
                  end
               end
               
           end
            
        end

        %Check if there are any XMLs
        [t, index] = ismember(docName, currentDirList);
        if t == 1; %ACTION
            xmlDirList=[xmlDirList
                strcat(MAINPATH,'/',docName)];
            
        end
            

        %Loop through the files to check for more dirs
        newDirs=cell(1,0);
        L=size(currentDirList,2);
        for i=1:L
            str=strcat(MAINPATH,'/',currentDirList{i});
            if isdir(str) == 1
                newDirs=[newDirs
                    str
                    ];
            end

        end

        if size(newDirs,2) > 0
            prevDirs=dirs(1:c);
            postDirs=dirs(c+1:end);
            dirs=[prevDirs
                newDirs
                postDirs];
        end


        c=c+1;
    else
        done = true;
    end
    
end



disp(xmlcounter)
end

