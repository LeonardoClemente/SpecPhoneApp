function newDataCell = guiColumnSort(parameterName,dataCell)

%Finding parameter on spreadsheet
names=dataCell(1,:);
[tf,index]=ismember(parameterName,names);



if tf == 1 %If parameter exist
         dataColumn=dataCell(2:end,index);

         [C,uniqueIndices,rebuildVector] = unique(dataColumn);
         
         [tf , index] = ismember('noData',C);
         
         if tf == 1
         offIndices=find(rebuildVector==index);
         dataColumn(offIndices(:))={'  -1'};
         end
         
         [tf, index] = ismember('OFF                 ',C);
         
         if tf == 1
         offIndices=find(rebuildVector==index);
         dataColumn(offIndices(:))={'  -2'};
         end
         
         [tf, index] = ismember('error',C);

         if tf == 1
         offIndices=find(rebuildVector==index);
         dataColumn(offIndices(:))={'  -3'};
         end
         
         
  [sortedColumn,sortedIndices]= sort(dataColumn);
        
    sortedIndices=sortedIndices+1;
    sortedIndices=[1
    sortedIndices];
else
   sortedIndices=1:size(dataCell,1); 
end


newDataCell=dataCell(sortedIndices(:),:);

end