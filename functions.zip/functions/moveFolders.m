function x = moveFolders(ABSPATH,seq_name,waypointName)%REWRITING DATA
             
             %Preparing directories and calling folder filler
             m_directory=strcat(ABSPATH);
             seq_directory=strcat(ABSPATH,'/',seq_name);
             waypoint_directory=strcat(ABSPATH,'/',waypointName);

             %Moving directory
             try
             filldir(m_directory,seq_directory,waypoint_directory,seq_name,waypointName);
             catch error
                 disp('Error while moving directories')
             end
             
end
            