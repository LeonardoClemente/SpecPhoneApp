function x = moveToError(ABSPATH,seq_name) %Moving to error folder
           
             %Preparing directories and calling folder filler
             seq_directory=strcat(ABSPATH,'/',seq_name);
             error_directory=strcat(ABSPATH,'/error');
             
             %Moving directory
             try
             filldir(ABSPATH,seq_directory,error_directory,seq_name,'error');
             catch error
                 disp('Error while moving directories')
             end
             
end
            