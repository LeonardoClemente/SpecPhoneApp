function x = organizeBy(parameterName,dataCell)

L=dataCell;

names=dataCell(1,1:107);
[tf index]=ismember(parameterName,names);

if tf == 1
    
    dataColumn=names(2:end,index);
    dataArray=convert2array(parameterName,dataColumn);
    
