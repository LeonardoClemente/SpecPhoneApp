function logs = specPhone_getAbsorbance(intensity,refIntensity)
    logs = -log10(im2double((intensity+1)./(refIntensity+1)));