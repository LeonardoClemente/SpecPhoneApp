function REGRESSION = specPhone_getAbsorbanceRegression(matrix)
    alpha = log(matrix(1,1)/matrix(2,1))/log(matrix(1,2)/matrix(2,2));
    k = matrix(1,1)/matrix(1,2)^alpha;
    logMatrix = log(matrix);
    REGRESSION = struct();
    REGRESSION.alpha = alpha;
    REGRESSION.k = k;
    REGRESSION.logMatrix = logMatrix; 