function DATA = specPhone_getHorizontalIntensity(image,rowIndex)
grayImage = rgb2gray(image);
n = size(grayImage,1);
rowAverages = mean(grayImage,2);

% rowAverages = mean(grayImage,2); %plotear
% [value, index] = max(rowAverages);

DATA = struct;
DATA.size = size(image);
DATA.rowAverages = rowAverages;
DATA.rgbIndex = rowIndex;
DATA.intensity = grayImage(columnindex,:);

 %// se elige un rango para la grafica para quitar la informacion innecesaria (obscuridad)
