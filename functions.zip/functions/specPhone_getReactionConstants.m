function [alpha, beta, k] = specPhone_getReactionConstants(dataMatrix,nReactions,eps,l)
    alpha = log(dataMatrix(1,1)/dataMatrix(2,1))/log(dataMatrix(1,2)/dataMatrix(2,2));
    if nReactions == 0
        beta=0
    else
        beta =  log(dataMatrix(2,1)/dataMatrix(3,1))/log(dataMatrix(1,2)/dataMatrix(2,2));
    end
    k = dataMatrix(1,1)/((dataMatrix(1,2)^alpha)*(dataMatrix(1,3)^2)^beta);
    
    