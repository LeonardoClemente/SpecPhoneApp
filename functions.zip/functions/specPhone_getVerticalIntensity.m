function DATA = specPhone_getVerticalIntensity(image,columnIndex)
s = size(image);
grayImage = squeeze(im2double(image(:,:,1)) +im2double(image(:,:,2)) + im2double(image(:,:,3)));
grayImage = grayImage/max(grayImage(:));
rowAverages = mean(grayImage,1);

% rowAverages = mean(grayImage,2); %plotear
% [value, index] = max(rowAverages);

DATA = struct;
DATA.size = size(image);
DATA.rowAverages = rowAverages;
DATA.rgbIndex = columnIndex;
DATA.intensity = grayImage(:,columnIndex);

 %// se elige un rango para la grafica para quitar la informacion innecesaria (obscuridad)
