function x = specPhone_pixel2slider(maxPixels,pixelPosition)
    x= pixelPostion/maxPixels