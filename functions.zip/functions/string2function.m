function [myFunction,parameters]= string2function(str,dataCell)
pCounter=1;

words=strsplit(str);
ones=strfind(words,'#');
L=size(words,2)
load('parameters.mat','LIST');
for i=1:L
    if(ones{i} == 1)
        pholder(pCounter)=i;
        pCounter=pCounter+1;
    end
end


%Checking if the parameters are part of the available data
pCounter=pCounter-1;
hashtagParameters=words(pholder(:));
parameters=strrep(hashtagParameters,'#','');
names=dataCell(1,:);
[tf index]=ismember(parameters,names);

L=size(tf,2);
if sum(tf) == size(tf,2)
    
    
%CHANGING STRING COMPARATION
    for i=1:L
             switch parameters{i}

                 case {'antennaPower','swversion','waypoint','cable0SerialNum', 'cable1SerialNum', 'cable2SerialNum','cable3SerialNum'...
                        'sensor0SerialNum','sensor1SerialNum','sensor2SerialNum','sensor3SerialNum','completionCode','DataSetName','UnitID'}
                 [tf index]=ismember(hashtagParameters{i},words);
                 nw=words{index+2};
                 str=strrep(str,nw,'1');
                 str=strrep(str,hashtagParameters{i},strcat('strcmp(',hashtagParameters{i},',',nw,')'));
             end
    end
%CREAR EL NUEVO STR
nstr=str;

for i=1:pCounter
    variable=strcat('a{',num2str(i),'}');
    nstr=strrep(nstr,hashtagParameters{i},variable);
end
start=strcat('@(a)',nstr);

myFunction=eval(start);

else
    myFunction=[];
    parameters=[];
    evStr=[];
end

