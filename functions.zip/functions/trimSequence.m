function t = trimSequence(n)

l=length(n);

t=n(1,l-6:end);
end