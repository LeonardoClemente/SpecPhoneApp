%TEST DE TRY CATCH

try 
   pen p 
catch error
    disp('error')
end

disp('todavia sigue')